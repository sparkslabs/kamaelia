============
Kamaelia Jam
============

Introduction
------------
Kamaelia Jam is a music sequencer designed for collaborative use over a network.  
