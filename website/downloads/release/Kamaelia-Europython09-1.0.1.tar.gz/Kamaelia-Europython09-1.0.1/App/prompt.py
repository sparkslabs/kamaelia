#!/usr/bin/python

raw_input(">> ")