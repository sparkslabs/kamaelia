int tiki_init(void);
int tiki_config(int time, int rate);
int tiki_close(void);
int tiki_seek(void);
unsigned long long tiki_getID1();
unsigned long long tiki_getID2();
int tiki_getReaderID();


