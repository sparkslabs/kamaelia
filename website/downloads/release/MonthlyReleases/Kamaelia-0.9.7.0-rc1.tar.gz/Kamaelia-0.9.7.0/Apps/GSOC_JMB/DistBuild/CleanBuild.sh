#!/bin/sh

cd ..
rm -rf AUTHORS Axon COPYING dist/ Docs/ Examples/ Kamaelia MANIFEST Tools/ Axon.CHANGELOG Kamaelia.CHANGELOG  setup.py Axon.README Kamaelia.README
