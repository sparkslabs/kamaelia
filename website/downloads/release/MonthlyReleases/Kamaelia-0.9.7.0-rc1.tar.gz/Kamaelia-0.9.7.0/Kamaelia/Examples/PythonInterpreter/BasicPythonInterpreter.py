#!/usr/bin/python

from Kamaelia.Experimental.PythonInterpreter import StandaloneInterpreter

StandaloneInterpreter().run()
