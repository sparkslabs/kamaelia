#!/bin/sh

cd ..
rm -rf Axon/ dist/ Kamaelia/ AUTHORS COPYING MANIFEST setup.py
