#!/bin/sh

cd ..
rm -rf AUTHORS Axon COPYING dist/ Kamaelia MANIFEST setup.py
