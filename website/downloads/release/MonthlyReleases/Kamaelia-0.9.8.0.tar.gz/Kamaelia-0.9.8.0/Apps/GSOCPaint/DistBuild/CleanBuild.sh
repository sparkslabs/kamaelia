#!/bin/sh

cd ..
rm -rf AUTHORS Axon COPYING dist  Kamaelia setup.py MANIFEST

