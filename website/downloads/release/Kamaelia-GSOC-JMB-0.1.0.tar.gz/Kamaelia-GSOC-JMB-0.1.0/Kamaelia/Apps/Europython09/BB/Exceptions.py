#!/usr/bin/python

class GotShutdownMessage(Exception):
    pass

