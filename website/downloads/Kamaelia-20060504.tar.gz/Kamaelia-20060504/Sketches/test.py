#!/usr/bin/env python

print """
This was a simple test script simply created to test whether
syncmail is installed right or not (!)
"""
