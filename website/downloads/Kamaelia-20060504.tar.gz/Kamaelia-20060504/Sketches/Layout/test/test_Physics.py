#!/usr/bin/env python

# some test code for Physics

import unittest
from Physics import *

class Physics_Test(unittest.TestCase):

        
        
if __name__=="__main__":
    unittest.main()
    