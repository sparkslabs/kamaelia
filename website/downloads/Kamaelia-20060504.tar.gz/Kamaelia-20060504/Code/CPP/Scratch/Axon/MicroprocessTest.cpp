#include "stdafx.h"
#include "MicroprocessTest.h"
#include "Microprocess.h"

// Registers the fixture into the 'registry'
CPPUNIT_TEST_SUITE_REGISTRATION( MicroprocessTest );

void
MicroprocessTest::setUp()
{
}


void
MicroprocessTest::tearDown()
{
}
void
MicroprocessTest::testConstructor()
{
  CPPUNIT_FAIL( "not implemented" );
}

void
MicroprocessTest::testExampleThrow()
{
  CPPUNIT_FAIL( "not implemented" );
}

